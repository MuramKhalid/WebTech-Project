const express = require('express');
const router = express.Router();
const User = require('../models/User'); 
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const { error } = require('console');

router.post('/register', async (req, res) => {
    try {
        const { username, email, password, confirmPassword } = req.body;
        
        if (password !== confirmPassword) {
            return res.status(400).send('Passwords do not match');
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
        return res.status(400).send('Email already registered');
    }
    
    const hashedPassword = await bcrypt.hash(password, 10);
    const activationCode = uuidv4();
    
    const user = new User({
        username,
        email,
        password: hashedPassword,
        activationCode,
        isActive: false
    });
    
    await user.save();
    console.log(`Activation Code: ${activationCode}`);

    res.redirect('/login');
} catch (err) {
    console.error(error);
    res.status(500).send('An error occurred. Please try again later.');
}
});

router.get('/activate/:code', async (req, res) => {
    const user = await User.findOne({ activationCode: req.params.code });
    if (!user) return res.status(400).send('Invalid activation code');
    
    user.isActive = true;
    user.activationCode = null;
    await user.save();
    res.send('Account activated successfully.');
});

router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user) return res.status(400).send('User not found');
    
    if (!user.isActive) return res.status(400).send('Account not activated');
    
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).send('Incorrect password');
    
    res.send('Login successful');
});

module.exports = router;
