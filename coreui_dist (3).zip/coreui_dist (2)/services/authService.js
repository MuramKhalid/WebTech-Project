const persistence = require('../data');
const nodemailer = require('nodemailer');
const crypto = require('crypto');

async function attemptLogin(username, password) {
    let details = await persistence.getUserDetails(username);
    let hash = crypto.createHash('sha256').update(password).digest('hex');
    if (!details || details.password !== hash || !details.active) {
        return undefined;
    }
    
    let sessionKey = crypto.randomUUID();
    let sessionData = {
        key: sessionKey,
        expiry: new Date(Date.now() + 1000 * 60 * 5),
        data: { username: details.username }
    };
    await persistence.startSession(sessionData);
    return sessionData;
}

async function terminateSession(key) {
    if (!key) return;
    await persistence.terminateSession(key);
}

async function getSession(key) {
    return await persistence.getSession(key);
}

async function resetPassword(email) {
    let details = await persistence.getUserByEmail(email);
    if (details) {
        let key = crypto.randomUUID();
        details.resetkey = key;
        await persistence.updateUser(details);
        
        let body = `A password reset request has been made for your account. Please <a href='http://127.0.0.1:8000/reset-password/?key=${key}'>click here</a> to reset your password.`;
        console.log(body); 
    }
}

async function checkReset(key) {
    return persistence.checkReset(key);
}

async function setPassword(key, password) {
    let hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
    await persistence.updatePassword(key, hashedPassword);
}

module.exports = {
    attemptLogin, terminateSession, getSession, 
    resetPassword, checkReset, setPassword
};
