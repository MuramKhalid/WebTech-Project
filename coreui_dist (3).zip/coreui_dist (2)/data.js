const mongoose = require('mongoose');
const User = require('./models/User'); 
const Session = require('../models/Session');

async function getUserDetails(username) {
    return await User.findOne({ username });
}

async function getUserByEmail(email) {
    return await User.findOne({ email });
}

async function updateUser(user) {
    return await User.findByIdAndUpdate(user._id, user, { new: true });
}

async function startSession(sessionData) {
    return await Session.create(sessionData);
}

async function getSession(key) {
    return await Session.findOne({ key, expiry: { $gt: new Date() } });
}


async function terminateSession(key) {
    return await Session.deleteOne({ key });
}


async function checkReset(key) {
    return await User.findOne({ resetkey: key });
}


async function updatePassword(key, hashedPassword) {
    let user = await User.findOne({ resetkey: key });
    if (user) {
        user.password = hashedPassword;
        user.resetkey = null; 
        await user.save();
    }
}

module.exports = {
    getUserDetails, getUserByEmail, updateUser, startSession, 
    getSession, terminateSession, checkReset, updatePassword
};
