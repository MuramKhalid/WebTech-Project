const mongoose = require('mongoose');

const sessionSchema = new mongoose.Schema({
    key: { type: String, required: true, unique: true },
    expiry: { type: Date, required: true },
    data: {
        username: { type: String, required: true }
    }
});

module.exports = mongoose.model('Session', sessionSchema);
